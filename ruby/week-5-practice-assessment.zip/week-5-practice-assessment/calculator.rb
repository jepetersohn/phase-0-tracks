calculator = {integer1: "", 
  operator: "", 
  integer2: ""
}

review=[]

loop do 
puts "What calculation would you like to perform: addition, subtraction, multiplication, or division? (Type 'done' when finished.)"
calculator[:operator] = gets.chomp 
if calculator[:operator] == "done" || calculator[:integer1] == "done" || calculator[:integer2] == "done"
  puts "Thank you for using this calculator."
  break
end
until  calculator[:operator] == 'addition'|| calculator[:operator] == 'subtraction' ||  calculator[:operator] == 'multiplication' ||  calculator[:operator] == 'division' ||  calculator[:operator] == 'done' 
  puts "I did not understand you. Please enter 'addition', 'subtraction', 'multiplication', 'division', or 'done'." 
  calculator[:operator] = gets.chomp 
end
puts "What is the first integer?"
calculator[:integer1] = gets.chomp.to_i

puts "What is the second integer?"
calculator[:integer2] = gets.chomp.to_i

if calculator[:operator] == "addition"
  puts calculator[:integer1] + calculator[:integer2]
elsif calculator[:operator] == "subtraction"
  puts calculator[:integer1] - calculator[:integer2]
elsif calculator[:operator] == "multiplication"
  puts calculator[:integer1] * calculator[:integer2]
elsif calculator[:operator] == "division"
  puts calculator[:integer1] / calculator[:integer2]  
elsif calculator[:operator] == "done" || calculator[:integer1] == "done" || calculator[:integer2] == "done"
  puts "Thank you for using this calculator."
else 
  puts "I did not understand you. Please enter 'addition', 'subtraction', 'multiplication', 'division', or 'done'."
  break
end
puts calculator
review << [calculator[:integer1], calculator[:operator], calculator[:integer2]]

end 


review.each do |integer1, operator, integer2|
    puts "#{calculator[:integer1]} #{calculator[:operator]} #{calculator[:integer2]}"
end
